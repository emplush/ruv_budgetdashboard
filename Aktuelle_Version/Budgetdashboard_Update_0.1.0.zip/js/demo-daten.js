/* Budgetdashboard: Beispieldaten für den Browserbetrieb (Artefakt, Demo). Alle Namen sind erfunden.
   Testzugänge: xv00000 (Administrator), xv10001 (Abteilungsleitung), xv10002 und xv10003 (Gruppenleitung),
   xv10004 (Key Account Manager), alle mit dem Passwort RuV-Plan#2026!. xv10005 hat noch ein Einmalpasswort. */
(function (wurzel) {
  "use strict";
  var PASSWORT = "RuV-Plan#2026!";

  function person(kennung, vorname, nachname, rolle, einmal) {
    return {
      kennung: kennung, vorname: vorname, nachname: nachname, rolle: rolle, salz: "", hash: "", einmalpasswort: "",
      mussPasswortAendern: !!einmal, design: "auto", farbe: "klassik", erstellt: new Date().toISOString(), letzteAnmeldung: "",
      _startPasswort: einmal || PASSWORT, _einmal: !!einmal
    };
  }

  function werte(pkId, pkAd, werbung, reise, sonstiges) {
    return { pkId: pkId, pkAd: pkAd, werbung: werbung, reise: reise, sonstiges: sonstiges };
  }

  function fuelle(daten) {
    var jahr = new Date().getFullYear();
    daten.benutzer.push(
      person("xv10001", "Sabine", "Hofmann", "al"),
      person("xv10002", "Thomas", "Becker", "gl"),
      person("xv10003", "Julia", "Wagner", "gl"),
      person("xv10004", "Daniel", "Schulz", "kam"),
      person("xv10005", "Laura", "Fischer", "kam", "Kq7#mPz2-wHte")
    );
    daten.kostenstellen = [
      { nummer: "410", benutzer: ["xv10001"] },
      { nummer: "411", benutzer: ["xv10002"] },
      { nummer: "412", benutzer: ["xv10002", "xv10003"] },
      { nummer: "413", benutzer: [] }
    ];
    daten.projekte = [
      { nummer: "41000101", benutzer: ["xv10004"] },
      { nummer: "41000102", benutzer: ["xv10004", "xv10005"] },
      { nummer: "41000103", benutzer: [] }
    ];
    daten.budgets[String(jahr)] = {
      "ks-410": werte(412000, 96000, 18000, 24500, 9800),
      "ks-411": werte(286500, 154000, 12000, 31000, 6500),
      "ks-412": werte(198000, 212500, 8500, 42000, 11200),
      "pn-41000101": werte(64000, 38000, 22000, 15500, 4000),
      "pn-41000102": werte(52000, 61000, 9000, 18000, 2500)
    };
    daten.budgets[String(jahr - 1)] = {
      "ks-410": werte(398000, 91000, 16500, 22000, 9000),
      "ks-411": werte(275000, 149000, 11000, 29500, 6000),
      "ks-412": werte(190000, 205000, 8000, 39000, 10500),
      "pn-41000101": werte(60000, 35000, 20000, 14000, 3500)
    };
  }

  wurzel.BDDemo = { fuelle: fuelle, PASSWORT: PASSWORT };
})(typeof self !== "undefined" ? self : this);
